plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.midipiano"
    compileSdk = 34

    defaultConfig {
        // 이전(접근성 터치 방식) 앱과 겹치지 않도록 새 앱 ID 사용
        applicationId = "com.example.midipianokeys"
        minSdk = 26
        // 33: 포그라운드 서비스 유형 선언 없이도 화면 위 버튼 서비스를 쓸 수 있음
        targetSdk = 33
        versionCode = 2
        versionName = "2.0"
    }

    // 매 빌드마다 같은 서명키를 써서, 다음에 다시 빌드한 APK도 덮어서 설치되게 함
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildFeatures {
        aidl = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
