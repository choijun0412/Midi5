package com.example.midipiano;

// Shizuku가 shell 권한 프로세스로 띄우는 키 입력 서비스의 인터페이스.
// (Shizuku 규칙: destroy()는 16777114번)
interface IKeyService {
    void destroy() = 16777114;

    // data[i] = (시작시각ms << 8) | (검은건반이면 0x80) | 안드로이드 keyCode
    // deviceMode: 0 = 가상 키보드로 입력, 1 = 폰의 실제 입력 장치 번호로 입력
    void play(in long[] data, int deviceMode) = 1;

    void stop() = 2;

    boolean isPlaying() = 3;

    String lastError() = 4;

    // 진단용 상태 문자열 (어떤 입력 장치로, 몇 번 성공했는지)
    String info() = 5;
}
