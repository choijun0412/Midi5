package com.example.midipiano;

// Shizuku가 shell 권한 프로세스로 띄우는 키 입력 서비스의 인터페이스.
// (Shizuku 규칙: destroy()는 16777114번, 나머지도 번호를 직접 붙여야 함)
interface IKeyService {
    void destroy() = 16777114;

    // data[i] = (시작시각ms << 8) | (검은건반이면 0x80) | 안드로이드 keyCode
    void play(in long[] data) = 1;

    void stop() = 2;

    boolean isPlaying() = 3;

    String lastError() = 4;
}
