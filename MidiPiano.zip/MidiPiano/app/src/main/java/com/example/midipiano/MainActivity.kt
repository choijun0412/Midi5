package com.example.midipiano

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var fileInfo: TextView
    private lateinit var floatBtn: Button

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            toast(
                if (result == PackageManager.PERMISSION_GRANTED) "Shizuku 권한이 허용됐어요"
                else "Shizuku 권한이 거부됐어요"
            )
            refresh()
        }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "MIDI → 로블록스 Virtual Piano (키보드 입력)"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        status = TextView(this).apply { setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)

        root.addView(button("① Shizuku 설치 / 열기") { openShizuku() })
        root.addView(button("② Shizuku 권한 허용") { askShizukuPermission() })
        root.addView(button("③ '다른 앱 위에 표시' 허용") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("④ MIDI 파일 선택") {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(i, "MIDI 파일 선택"), REQ_MIDI)
        })
        fileInfo = TextView(this).apply {
            text = "선택된 파일 없음"
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(fileInfo)

        root.addView(section("연주 설정"))
        slider(root, "음높이 이동 (반음)", "transpose", -24, 24) { (if (it > 0) "+" else "") + it }
        slider(root, "속도 배율", "speed", 25, 300) { String.format("%.2f배", it / 100f) }

        floatBtn = button("⑤ 화면 위 버튼 켜기") { toggleFloating() }
        root.addView(floatBtn)

        root.addView(TextView(this).apply {
            setPadding(0, pad, 0, 0)
            text = "사용법\n" +
                "1) ①~④를 순서대로 끝내요. (Shizuku는 시작되어 있어야 해요)\n" +
                "2) ⑤로 화면 위 버튼을 켜요. 초록 ▶ 버튼이 떠요.\n" +
                "3) 로블록스 Virtual Piano를 열고 ▶를 누르면 시작, 빨간 ■를 누르면 멈춰요.\n" +
                "4) 버튼을 길게 누르면 도레미파솔라시도 테스트가 나와요. 소리가 나면 키보드 입력이 잘 되는 거예요.\n" +
                "5) 버튼은 끌어서 옮길 수 있어요. 폰을 재부팅하면 Shizuku를 다시 시작해야 해요."
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------------- 상태 ----------------

    private fun refresh() {
        val installed = try {
            packageManager.getPackageInfo(SHIZUKU_PKG, 0)
            true
        } catch (_: Exception) {
            false
        }
        val running = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
        val granted = running && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
        val overlay = Settings.canDrawOverlays(this)

        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = "${mark(installed)} Shizuku 설치됨\n" +
            "${mark(running)} Shizuku 실행 중\n" +
            "${mark(granted)} Shizuku 권한 허용\n" +
            "${mark(overlay)} 다른 앱 위에 표시 허용\n" +
            "${mark(Shared.midi != null)} MIDI 파일 선택"
        floatBtn.text = if (FloatingService.running) "⑤ 화면 위 버튼 끄기" else "⑤ 화면 위 버튼 켜기"
    }

    // ---------------- 동작 ----------------

    private fun openShizuku() {
        val launch = packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
        if (launch != null) {
            startActivity(launch)
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PKG")))
        } catch (_: Exception) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PKG")
                )
            )
        }
    }

    private fun askShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku가 아직 시작되지 않았어요. ①에서 Shizuku를 열어 시작하세요")
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("이미 허용돼 있어요")
            } else {
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
            toast("Shizuku 오류: ${e.message}")
        }
    }

    private fun toggleFloating() {
        val svc = Intent(this, FloatingService::class.java)
        if (FloatingService.running) {
            stopService(svc)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                toast("③ '다른 앱 위에 표시'를 먼저 허용하세요")
                return
            }
            startForegroundService(svc)
        }
        floatBtn.postDelayed({ refresh() }, 400)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MIDI || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val midi = MidiParser.parse(bytes)
            Shared.midi = midi
            Shared.name = displayName(uri)
            val sec = midi.lengthMs / 1000
            fileInfo.text = "${Shared.name}\n음 ${midi.notes.size}개, 길이 ${sec / 60}분 ${sec % 60}초"
            refresh()
        } catch (e: Exception) {
            toast("불러오기 실패: ${e.message}")
        }
    }

    // ---------------- 도우미 ----------------

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment ?: "midi"
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun section(label: String): TextView =
        TextView(this).apply {
            text = label
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (16 * resources.displayMetrics.density).toInt(), 0, 0)
        }

    private fun slider(
        parent: LinearLayout, label: String, key: String,
        min: Int, max: Int, fmt: (Int) -> String
    ) {
        val prefs = getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE)
        val cur = prefs.getInt(key, Cfg.DEFAULTS.getValue(key)).coerceIn(min, max)
        val tv = TextView(this).apply { text = "$label: ${fmt(cur)}" }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    prefs.edit().putInt(key, v).apply()
                    tv.text = "$label: ${fmt(v)}"
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val REQ_MIDI = 1
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    }
}
