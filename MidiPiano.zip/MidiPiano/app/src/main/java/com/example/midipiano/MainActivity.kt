package com.example.midipiano

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var fileInfo: TextView
    private lateinit var floatBtn: Button
    private lateinit var keyLog: TextView
    private lateinit var diagView: TextView
    private val keyHistory = StringBuilder()

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN && ::keyLog.isInitialized) {
            val name = android.view.KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
            if (keyHistory.length > 80) keyHistory.delete(0, keyHistory.length - 60)
            keyHistory.append(name).append(if (event.isShiftPressed) "(Shift) " else " ")
            keyLog.text = "받은 키: $keyHistory"
        }
        return super.dispatchKeyEvent(event)
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            toast(
                if (result == PackageManager.PERMISSION_GRANTED) "Shizuku 권한이 허용됐어요"
                else "Shizuku 권한이 거부됐어요"
            )
            refresh()
        }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "MIDI → 로블록스 Virtual Piano (키보드 입력)"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        status = TextView(this).apply { setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)

        root.addView(button("① Shizuku 설치 / 열기") { openShizuku() })
        root.addView(button("② Shizuku 권한 허용") { askShizukuPermission() })
        root.addView(button("③ '다른 앱 위에 표시' 허용") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("④ MIDI 파일 선택") {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(i, "MIDI 파일 선택"), REQ_MIDI)
        })
        fileInfo = TextView(this).apply {
            text = "선택된 파일 없음"
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(fileInfo)

        root.addView(section("연주 설정"))
        slider(root, "음높이 이동 (반음)", "transpose", -24, 24) { (if (it > 0) "+" else "") + it }
        slider(root, "속도 배율", "speed", 25, 300) { String.format("%.2f배", it / 100f) }
        slider(root, "키 입력 장치 (0=가상 키보드, 1=폰의 실제 입력 장치)", "devMode", 0, 1) {
            if (it == 0) "0 (가상)" else "1 (실제 장치)"
        }

        root.addView(section("키 입력 확인"))
        root.addView(TextView(this).apply {
            text = "이 앱 화면을 켜 둔 채로 ⑤ 버튼의 ▶를 길게 누르면(도레미 테스트) 아래에 받은 키가 표시돼요. " +
                "여기에 키가 찍히면 키 입력 자체는 잘 만들어지는 거예요."
        })
        keyLog = TextView(this).apply {
            text = "받은 키: (없음)"
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(keyLog)

        root.addView(section("진단 정보"))
        diagView = TextView(this).apply {
            textSize = 14f
            setPadding(0, pad / 2, 0, pad / 2)
            setTextIsSelectable(true)
        }
        root.addView(diagView)
        root.addView(button("⑥ 입력 방법별 진단 (앱 화면을 켜 두고 10초 기다리기)") {
            keyHistory.setLength(0)
            keyLog.text = "받은 키: (없음)"
            Diag.note = "진단 중… 앱 화면을 켜 둔 채 10초쯤 기다린 뒤 '진단 정보 새로고침'을 누르세요"
            startForegroundService(
                Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_DIAG)
            )
            refresh()
        })
        root.addView(button("진단 정보 새로고침") { refresh() })

        floatBtn = button("⑤ 화면 위 버튼 켜기") { toggleFloating() }
        root.addView(floatBtn)

        root.addView(TextView(this).apply {
            setPadding(0, pad, 0, 0)
            text = "사용법\n" +
                "1) ①~④를 순서대로 끝내요. (Shizuku는 시작되어 있어야 해요)\n" +
                "2) ⑤로 화면 위 버튼을 켜요. 초록 ▶ 버튼이 떠요.\n" +
                "3) 로블록스 Virtual Piano를 열고 ▶를 누르면 시작, 빨간 ■를 누르면 멈춰요.\n" +
                "4) 버튼을 길게 누르면 도레미파솔라시도 테스트가 나와요. 소리가 나면 키보드 입력이 잘 되는 거예요.\n" +
                "5) 버튼은 끌어서 옮길 수 있어요. 폰을 재부팅하면 Shizuku를 다시 시작해야 해요."
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------------- 상태 ----------------

    private fun refresh() {
        val installed = try {
            packageManager.getPackageInfo(SHIZUKU_PKG, 0)
            true
        } catch (_: Exception) {
            false
        }
        val running = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
        val granted = running && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
        val overlay = Settings.canDrawOverlays(this)

        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = "${mark(installed)} Shizuku 설치됨\n" +
            "${mark(running)} Shizuku 실행 중\n" +
            "${mark(granted)} Shizuku 권한 허용\n" +
            "${mark(overlay)} 다른 앱 위에 표시 허용\n" +
            "${mark(Shared.midi != null)} MIDI 파일 선택"
        floatBtn.text = if (FloatingService.running) "⑤ 화면 위 버튼 끄기" else "⑤ 화면 위 버튼 켜기"
        if (::diagView.isInitialized) {
            diagView.text = Diag.serviceInfo +
                (if (Diag.note.isNotEmpty()) "\n\n" + Diag.note else "")
        }
    }

    // ---------------- 동작 ----------------

    private fun openShizuku() {
        val launch = packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
        if (launch != null) {
            startActivity(launch)
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PKG")))
        } catch (_: Exception) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PKG")
                )
            )
        }
    }

    private fun askShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku가 아직 시작되지 않았어요. ①에서 Shizuku를 열어 시작하세요")
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("이미 허용돼 있어요")
            } else {
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
            toast("Shizuku 오류: ${e.message}")
        }
    }

    private fun toggleFloating() {
        val svc = Intent(this, FloatingService::class.java)
        if (FloatingService.running) {
            stopService(svc)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                toast("③ '다른 앱 위에 표시'를 먼저 허용하세요")
                return
            }
            startForegroundService(svc)
        }
        floatBtn.postDelayed({ refresh() }, 400)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MIDI || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val midi = MidiParser.parse(bytes)
            Shared.midi = midi
            Shared.name = displayName(uri)
            val sec = midi.lengthMs / 1000
            fileInfo.text = "${Shared.name}\n음 ${midi.notes.size}개, 길이 ${sec / 60}분 ${sec % 60}초"
            refresh()
        } catch (e: Exception) {
            toast("불러오기 실패: ${e.message}")
        }
    }

    // ---------------- 도우미 ----------------

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment ?: "midi"
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun section(label: String): TextView =
        TextView(this).apply {
            text = label
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (16 * resources.displayMetrics.density).toInt(), 0, 0)
        }

    private fun slider(
        parent: LinearLayout, label: String, key: String,
        min: Int, max: Int, fmt: (Int) -> String
    ) {
        val prefs = getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE)
        val cur = prefs.getInt(key, Cfg.DEFAULTS.getValue(key)).coerceIn(min, max)
        val tv = TextView(this).apply { text = "$label: ${fmt(cur)}" }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    prefs.edit().putInt(key, v).apply()
                    tv.text = "$label: ${fmt(v)}"
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val REQ_MIDI = 1
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    }
}
