package com.example.midipiano

import android.content.Context

/** 설정 화면의 슬라이더 값 (SharedPreferences) */
class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun v(key: String) = p.getInt(key, DEFAULTS.getValue(key))

    val transpose get() = v("transpose")   // 반음 이동
    val speed get() = v("speed") / 100f    // 속도 배율

    companion object {
        const val PREFS = "cfg"
        val DEFAULTS = mapOf(
            "transpose" to 0,
            "speed" to 100
        )
    }
}

/** MIDI 노트 번호(C2=36 ~ C7=96) -> Virtual Piano 61키 배열의 키보드 키 */
object KeyLayout {
    const val LOW = 36
    const val HIGH = 96
    private const val NATURALS = "1234567890qwertyuiopasdfghjklzxcvbnm"
    private val WHITE_IDX = intArrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
    private val BLACK = booleanArrayOf(false, true, false, true, false, false, true, false, true, false, true, false)

    /** 범위를 벗어난 음은 옥타브를 옮겨 61키 안으로 */
    fun fit(note: Int): Int {
        var n = note
        while (n < LOW) n += 12
        while (n > HIGH) n -= 12
        return n
    }

    /** 안드로이드 keyCode(0~127). 검은 건반(Shift+키)이면 0x80을 더해서 돌려준다. */
    fun keyFor(note: Int): Int {
        val rel = fit(note) - LOW
        val idx = (rel / 12) * 7 + WHITE_IDX[rel % 12]
        val ch = NATURALS[idx]
        val code = if (ch in '0'..'9') {
            if (ch == '0') 7 else 8 + (ch - '1')   // KEYCODE_0=7, KEYCODE_1=8 ...
        } else {
            29 + (ch - 'a')                         // KEYCODE_A=29 ...
        }
        return if (BLACK[rel % 12]) code or 0x80 else code
    }
}

/** 곡을 키 입력 서비스에 보낼 형태로 묶는다: (시작ms << 8) | 키 정보 */
object Packer {
    fun pack(notes: List<NoteAt>, c: Cfg): LongArray {
        val speed = maxOf(c.speed, 0.1f)
        return LongArray(notes.size) { i ->
            val n = notes[i]
            val t = (n.ms / speed).toLong()
            (t shl 8) or KeyLayout.keyFor(n.note + c.transpose).toLong()
        }
    }
}
