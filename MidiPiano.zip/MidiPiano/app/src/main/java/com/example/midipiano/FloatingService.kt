package com.example.midipiano

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

/**
 * 다른 앱(로블록스) 위에 ▶/■ 버튼을 띄우고,
 * Shizuku로 띄운 키 입력 서비스에 곡 재생/정지를 시킨다.
 * 버튼: 한 번 누르면 시작/정지, 길게 누르면 도레미파솔라시도 테스트, 끌면 이동.
 */
class FloatingService : Service() {

    companion object {
        @Volatile
        var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var button: TextView? = null

    private var keySvc: IKeyService? = null
    private var binding = false
    private var wasPlaying = false
    private var shownPlaying = false

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, KeyService::class.java.name))
            .processNameSuffix("keys")
            .daemon(false)
            .version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            keySvc = if (binder != null && binder.pingBinder()) IKeyService.Stub.asInterface(binder) else null
            if (keySvc != null) toast("키보드 입력 연결됨")
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            keySvc = null
            binding = false
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            val s = keySvc
            var playing = false
            if (s != null) {
                try {
                    playing = s.isPlaying()
                    if (wasPlaying && !playing) {
                        val err = s.lastError()
                        if (!err.isNullOrEmpty()) toast("키 입력 오류: $err")
                    }
                } catch (e: Exception) {
                    keySvc = null
                    binding = false
                }
            }
            wasPlaying = playing
            updateButton(playing)
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (button == null) showButton()
        connect()
        handler.removeCallbacks(poll)
        handler.post(poll)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            keySvc?.stop()
        } catch (_: Exception) {
        }
        try {
            if (keySvc != null || binding) Shizuku.unbindUserService(userServiceArgs, conn, true)
        } catch (_: Throwable) {
        }
        keySvc = null
        hideButton()
        running = false
        super.onDestroy()
    }

    // ---------------- Shizuku 연결 ----------------

    private fun connect() {
        if (keySvc != null || binding) return
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku가 꺼져 있어요. Shizuku 앱에서 시작하세요")
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                toast("앱에서 'Shizuku 권한 허용'을 먼저 눌러 주세요")
                return
            }
            binding = true
            Shizuku.bindUserService(userServiceArgs, conn)
        } catch (e: Throwable) {
            binding = false
            toast("Shizuku 연결 실패: ${e.message}")
        }
    }

    // ---------------- 재생 ----------------

    private fun toggle() {
        val s = keySvc
        if (s == null) {
            connect()
            toast("키보드 연결 중이에요. 잠시 후 다시 눌러 주세요")
            return
        }
        try {
            if (s.isPlaying()) {
                s.stop()
                return
            }
            val midi = Shared.midi
            if (midi == null) {
                toast("앱에서 MIDI 파일을 먼저 선택하세요")
                return
            }
            s.play(Packer.pack(midi.notes, Cfg(this)))
        } catch (e: Exception) {
            toast("오류: ${e.message}")
            keySvc = null
            binding = false
        }
    }

    /** 도레미파솔라시도: 키 입력이 로블록스에 들어가는지 확인용 */
    private fun testScale() {
        val s = keySvc
        if (s == null) {
            connect()
            toast("키보드가 아직 연결되지 않았어요")
            return
        }
        val notes = intArrayOf(60, 62, 64, 65, 67, 69, 71, 72)
        val data = LongArray(notes.size) { i ->
            ((i * 350L) shl 8) or KeyLayout.keyFor(notes[i]).toLong()
        }
        try {
            s.play(data)
        } catch (e: Exception) {
            toast("오류: ${e.message}")
        }
    }

    // ---------------- 화면 위 버튼 ----------------

    private fun showButton() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "▶"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC2E7D32"))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 120
        }

        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        var longFired = false
        val longPress = Runnable {
            longFired = true
            testScale()
        }

        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    downX = ev.rawX
                    downY = ev.rawY
                    moved = false
                    longFired = false
                    handler.postDelayed(longPress, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = ev.rawX - downX
                    val my = ev.rawY - downY
                    if (moved || Math.abs(mx) > 12 || Math.abs(my) > 12) {
                        moved = true
                        handler.removeCallbacks(longPress)
                        lp.x = startX + mx.toInt()
                        lp.y = startY + my.toInt()
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (!moved && !longFired) toggle()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
            }
            true
        }
        try {
            wm.addView(tv, lp)
            button = tv
        } catch (e: Exception) {
            toast("버튼을 띄우지 못했어요. '다른 앱 위에 표시'를 허용했는지 확인하세요")
        }
    }

    private fun hideButton() {
        button?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        button = null
    }

    private fun updateButton(playing: Boolean) {
        val tv = button ?: return
        if (playing == shownPlaying && tv.text.isNotEmpty()) return
        shownPlaying = playing
        tv.text = if (playing) "■" else "▶"
        (tv.background as? GradientDrawable)?.setColor(
            Color.parseColor(if (playing) "#CCC62828" else "#CC2E7D32")
        )
    }

    // ---------------- 도우미 ----------------

    private fun buildNotification(): Notification {
        val channelId = "midipiano"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "MIDI 피아노", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("MIDI 피아노 실행 중")
            .setContentText("화면 위 버튼으로 시작/정지")
            .build()
    }

    private fun toast(msg: String) {
        handler.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }
}
