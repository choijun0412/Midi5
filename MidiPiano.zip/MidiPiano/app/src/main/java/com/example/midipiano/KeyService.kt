package com.example.midipiano

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent

/**
 * Shizuku가 shell 권한 프로세스로 실행하는 서비스.
 * 여기서 진짜 키보드 키 이벤트(KeyEvent)를 시스템에 넣는다.
 * 곡 전체를 한 번에 받아서 이 프로세스 안에서 박자를 맞춰 치므로 지연이 적다.
 */
class KeyService : IKeyService.Stub() {

    @Volatile private var stopFlag = false
    @Volatile private var playingFlag = false
    @Volatile private var error: String = ""
    @Volatile private var okCount = 0
    @Volatile private var failCount = 0
    private var thread: Thread? = null

    // 키 이벤트를 넣는 방법들 (안드로이드 버전마다 되는 게 달라서 순서대로 시도)
    private val strategies = ArrayList<(InputEvent) -> Boolean>()
    private val prepNotes = ArrayList<String>()
    private var good = -1

    // 키 이벤트에 실을 입력 장치 번호
    @Volatile private var devId = KeyCharacterMap.VIRTUAL_KEYBOARD
    @Volatile private var devName = "가상 키보드"

    init {
        val intType = Int::class.javaPrimitiveType!!

        // 방법 1: IInputManager 바인더에 직접 주입
        try {
            val binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java)
                .invoke(null, "input") as IBinder
            val iface = Class.forName("android.hardware.input.IInputManager")
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
                .getMethod("asInterface", IBinder::class.java)
                .invoke(null, binder)
            val m = iface.getMethod("injectInputEvent", InputEvent::class.java, intType)
            strategies.add { ev -> (m.invoke(stub, ev, 0) as? Boolean) ?: true }
            prepNotes.add("방법1 준비됨")
        } catch (e: Throwable) {
            prepNotes.add("방법1 실패: ${(e.cause ?: e)}")
        }

        // 방법 2: InputManager.getInstance()
        try {
            val cls = Class.forName("android.hardware.input.InputManager")
            val gi = cls.getDeclaredMethod("getInstance")
            gi.isAccessible = true
            val im = gi.invoke(null)
            val m = cls.getMethod("injectInputEvent", InputEvent::class.java, intType)
            strategies.add { ev -> (m.invoke(im, ev, 0) as? Boolean) ?: true }
            prepNotes.add("방법2 준비됨")
        } catch (e: Throwable) {
            prepNotes.add("방법2 실패: ${(e.cause ?: e)}")
        }
    }

    override fun destroy() {
        stop()
        System.exit(0)
    }

    override fun play(data: LongArray?, deviceMode: Int) {
        stop()
        pickDevice(deviceMode)
        if (data == null || data.isEmpty()) return
        stopFlag = false
        error = ""
        playingFlag = true
        val t = Thread { runSong(data) }
        t.isDaemon = true
        thread = t
        t.start()
    }

    override fun stop() {
        stopFlag = true
        val t = thread
        if (t != null && t !== Thread.currentThread()) {
            try {
                t.join(500)
            } catch (_: InterruptedException) {
            }
        }
    }

    override fun isPlaying(): Boolean = playingFlag

    override fun lastError(): String = error

    private fun pickDevice(mode: Int) {
        devId = KeyCharacterMap.VIRTUAL_KEYBOARD
        devName = "가상 키보드"
        if (mode != 1) return
        try {
            var best: InputDevice? = null
            for (id in InputDevice.getDeviceIds()) {
                val d = InputDevice.getDevice(id) ?: continue
                if (d.isVirtual) continue
                if ((d.sources and InputDevice.SOURCE_KEYBOARD) != InputDevice.SOURCE_KEYBOARD) continue
                val alpha = d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
                val bestAlpha = best?.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
                if (best == null || (alpha && !bestAlpha)) best = d
            }
            if (best != null) {
                devId = best.id
                devName = best.name
            } else {
                devName = "가상 키보드 (실제 장치 없음)"
            }
        } catch (e: Throwable) {
            error = "장치 찾기 실패: $e"
        }
    }

    override fun info(): String {
        val sb = StringBuilder()
        sb.append("권한 uid=").append(android.os.Process.myUid())
            .append(if (android.os.Process.myUid() == 2000) " (adb shell)" else if (android.os.Process.myUid() == 0) " (root)" else "")
            .append('\n')
        prepNotes.forEach { sb.append(it).append('\n') }
        sb.append("성공한 입력 ").append(okCount).append("회, 실패 ").append(failCount).append("회\n")
        sb.append("사용 중인 방법: ").append(if (good >= 0) "방법${good + 1}" else "아직 없음").append('\n')
        sb.append("입력 장치: ").append(devId).append(" (").append(devName).append(")\n")
        if (error.isNotEmpty()) sb.append("마지막 오류: ").append(error)
        return sb.toString()
    }

    // ---------------- 연주 ----------------

    private fun runSong(data: LongArray) {
        try {
            val t0 = SystemClock.uptimeMillis() + 150
            var i = 0
            while (i < data.size && !stopFlag) {
                val gt = data[i] ushr 8
                val plain = ArrayList<Int>()
                val shifted = ArrayList<Int>()
                var j = i
                // 25ms 안에 같이 울리는 음은 화음으로 묶어서 동시에 누른다
                while (j < data.size && (data[j] ushr 8) - gt <= 25) {
                    val code = (data[j] and 0x7FL).toInt()
                    if ((data[j] and 0x80L) != 0L) {
                        if (!shifted.contains(code)) shifted.add(code)
                    } else {
                        if (!plain.contains(code)) plain.add(code)
                    }
                    j++
                }
                val target = t0 + gt
                while (!stopFlag) {
                    val w = target - SystemClock.uptimeMillis()
                    if (w <= 0) break
                    Thread.sleep(minOf(w, 4L))
                }
                if (stopFlag) break
                pressGroup(plain, shifted)
                i = j
            }
        } catch (_: InterruptedException) {
        } catch (e: Throwable) {
            error = e.toString()
        } finally {
            playingFlag = false
        }
    }

    private fun pressGroup(plain: List<Int>, shifted: List<Int>) {
        val shiftMeta = KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        for (c in plain) key(c, true, 0)
        if (shifted.isNotEmpty()) {
            key(KeyEvent.KEYCODE_SHIFT_LEFT, true, KeyEvent.META_SHIFT_ON)
            for (c in shifted) key(c, true, shiftMeta)
        }
        Thread.sleep(30)
        for (c in shifted) key(c, false, shiftMeta)
        if (shifted.isNotEmpty()) key(KeyEvent.KEYCODE_SHIFT_LEFT, false, 0)
        for (c in plain) key(c, false, 0)
    }

    /** 안드로이드 keyCode -> 리눅스 스캔코드 (실제 키보드처럼 보이게) */
    private fun scanCode(code: Int): Int {
        val rows = arrayOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm")
        val starts = intArrayOf(2, 16, 30, 44)
        val ch: Char = when (code) {
            in 29..54 -> 'a' + (code - 29)
            7 -> '0'
            in 8..16 -> '1' + (code - 8)
            KeyEvent.KEYCODE_SHIFT_LEFT -> return 42
            else -> return 0
        }
        for (r in rows.indices) {
            val k = rows[r].indexOf(ch)
            if (k >= 0) return starts[r] + k
        }
        return 0
    }

    private fun key(code: Int, down: Boolean, meta: Int) {
        val now = SystemClock.uptimeMillis()
        val ev = KeyEvent(
            now, now,
            if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP,
            code, 0, meta,
            devId, scanCode(code), 0,
            InputDevice.SOURCE_KEYBOARD
        )
        inject(ev)
    }

    private fun inject(ev: InputEvent) {
        if (good >= 0) {
            try {
                if (strategies[good](ev)) {
                    okCount++
                    return
                }
            } catch (e: Throwable) {
                error = (e.cause ?: e).toString()
            }
            good = -1
        }
        for (i in strategies.indices) {
            try {
                if (strategies[i](ev)) {
                    good = i
                    okCount++
                    return
                } else {
                    error = "키 입력이 거부됨(방법 ${i + 1})"
                }
            } catch (e: Throwable) {
                error = (e.cause ?: e).toString()
            }
        }
        failCount++
        if (strategies.isEmpty() && error.isEmpty()) error = "키 입력 방법을 찾지 못함"
    }
}
