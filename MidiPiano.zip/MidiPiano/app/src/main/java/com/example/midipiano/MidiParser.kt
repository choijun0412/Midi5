package com.example.midipiano

/** 연주할 음 하나: 시작 시각(ms)과 MIDI 노트 번호 */
class NoteAt(val ms: Long, val note: Int)

class MidiData(val notes: List<NoteAt>) {
    val lengthMs: Long get() = notes.lastOrNull()?.ms ?: 0L
}

/** 앱과 서비스가 같이 쓰는 현재 선택된 MIDI */
object Shared {
    @Volatile var midi: MidiData? = null
    @Volatile var name: String = ""
}

object MidiParser {

    private class Reader(val d: ByteArray, var p: Int = 0) {
        fun u8(): Int = d[p++].toInt() and 0xFF
        fun u16(): Int = (u8() shl 8) or u8()
        fun u32(): Int = (u16() shl 16) or u16()
        fun vlq(): Int {
            var v = 0
            while (true) {
                val b = u8()
                v = (v shl 7) or (b and 0x7F)
                if (b and 0x80 == 0) return v
            }
        }
    }

    fun parse(data: ByteArray): MidiData {
        require(data.size > 14 && String(data, 0, 4, Charsets.ISO_8859_1) == "MThd") {
            "MIDI 파일이 아닙니다"
        }
        val r = Reader(data, 4)
        val headerLen = r.u32()
        r.u16() // format
        val trackCount = r.u16()
        val division = r.u16()
        r.p = 8 + headerLen
        val ppq = if (division and 0x8000 != 0) 480 else maxOf(division, 1)

        val noteEvents = ArrayList<LongArray>() // [tick, note]
        val tempos = ArrayList<LongArray>()     // [tick, microsPerQuarter]

        repeat(trackCount) {
            if (r.p + 8 > data.size) return@repeat
            val tag = String(data, r.p, 4, Charsets.ISO_8859_1)
            r.p += 4
            val len = r.u32()
            val end = minOf(r.p + len, data.size)
            if (tag != "MTrk") {
                r.p = end
                return@repeat
            }
            var tick = 0L
            var running = 0
            while (r.p < end) {
                tick += r.vlq()
                var st = r.u8()
                if (st < 0x80) {
                    r.p--
                    st = running
                } else if (st < 0xF0) {
                    running = st
                }
                when {
                    st == 0xFF -> {
                        val type = r.u8()
                        val l = r.vlq()
                        if (type == 0x51 && l == 3) {
                            val us = (r.u8() shl 16) or r.u16()
                            tempos.add(longArrayOf(tick, us.toLong()))
                        } else {
                            r.p += l
                        }
                    }
                    st == 0xF0 || st == 0xF7 -> {
                        val l = r.vlq()
                        r.p += l
                    }
                    else -> {
                        val hi = st and 0xF0
                        val ch = st and 0x0F
                        val a = r.u8()
                        if (hi == 0xC0 || hi == 0xD0) {
                            // 데이터 바이트 1개짜리 이벤트
                        } else {
                            val b = r.u8()
                            if (hi == 0x90 && b > 0 && ch != 9) {
                                noteEvents.add(longArrayOf(tick, a.toLong()))
                            }
                        }
                    }
                }
            }
            r.p = end
        }

        tempos.sortBy { it[0] }
        noteEvents.sortBy { it[0] }

        // 템포 구간: (시작 tick, 그 시점의 ms, 마이크로초/4분음표)
        val segTick = ArrayList<Long>()
        val segMs = ArrayList<Double>()
        val segUs = ArrayList<Long>()
        segTick.add(0L); segMs.add(0.0); segUs.add(500000L)
        var curUs = 500000L
        var lastTick = 0L
        var ms = 0.0
        for (t in tempos) {
            ms += (t[0] - lastTick).toDouble() * curUs / ppq / 1000.0
            lastTick = t[0]
            curUs = t[1]
            segTick.add(lastTick); segMs.add(ms); segUs.add(curUs)
        }

        val out = ArrayList<NoteAt>(noteEvents.size)
        var seg = 0
        var prevMs = -1L
        var prevNote = -1
        for (e in noteEvents) {
            while (seg + 1 < segTick.size && segTick[seg + 1] <= e[0]) seg++
            val t = (segMs[seg] + (e[0] - segTick[seg]).toDouble() * segUs[seg] / ppq / 1000.0).toLong()
            val n = e[1].toInt()
            if (t == prevMs && n == prevNote) continue
            out.add(NoteAt(t, n))
            prevMs = t
            prevNote = n
        }
        require(out.isNotEmpty()) { "연주할 음이 없는 파일입니다" }
        return MidiData(out)
    }
}
